var path = require("path");

module.exports = {
  includePaths: [
    path.join(__dirname, "_sass/hamburgers")
  ]
};
